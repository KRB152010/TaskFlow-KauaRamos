import { useMemo, useState } from "react"

type IconName = "arrow" | "atom" | "book" | "brain" | "check" | "chevron" | "clock" | "flask" | "globe" | "graduation" | "math" | "menu" | "play" | "spark" | "star" | "user" | "users"

function Icon({
  name,
  className = "size-5",
}: {
  name: IconName
  className?: string
}) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14M13 6l6 6-6 6" />
      </>
    ),
    atom: (
      <>
        <circle cx="12" cy="12" r="1.5" />
        <path d="M18.3 5.7c2 2-1.2 8.5-6.3 13.6M5.7 5.7c-2 2 1.2 8.5 6.3 13.6M3.5 12c0-2.8 7.6-4.8 15.3-2.8M5.2 16c2.4 1.4 8-4.1 12-10.8" />
      </>
    ),
    book: (
      <>
        <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H11v16H6.5A2.5 2.5 0 0 0 4 21.5zM20 5.5A2.5 2.5 0 0 0 17.5 3H13v16h4.5a2.5 2.5 0 0 1 2.5 2.5z" />
      </>
    ),
    brain: (
      <>
        <path d="M9.5 4.3A3 3 0 0 0 4.7 7a3 3 0 0 0-.2 5.7A3.5 3.5 0 0 0 8 18.5h1.5V4.3ZM14.5 4.3A3 3 0 0 1 19.3 7a3 3 0 0 1 .2 5.7 3.5 3.5 0 0 1-3.5 5.8h-1.5V4.3ZM9.5 8H7M14.5 8H17M9.5 14H7.5M14.5 14h2" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    flask: (
      <>
        <path d="M9 3h6M10 3v6l-5 8.5A2.3 2.3 0 0 0 7 21h10a2.3 2.3 0 0 0 2-3.5L14 9V3" />
        <path d="M7.5 16h9" />
      </>
    ),
    globe: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" />
      </>
    ),
    graduation: (
      <>
        <path d="m3 9 9-5 9 5-9 5z" />
        <path d="M7 12v4c3 2 7 2 10 0v-4M21 9v6" />
      </>
    ),
    math: (
      <>
        <path d="M5 7h6M8 4v6M14 6h5M14 10h5M5 16h6M16.5 14l-3 5M13.5 14l3 5" />
      </>
    ),
    menu: (
      <>
        <path d="M4 7h16M4 12h16M4 17h16" />
      </>
    ),
    play: <path d="m9 7 8 5-8 5z" />,
    spark: (
      <>
        <path d="m12 3 1.2 4.3L17 9l-3.8 1.7L12 15l-1.2-4.3L7 9l3.8-1.7zM5 14l.7 2.3L8 17l-2.3.7L5 20l-.7-2.3L2 17l2.3-.7z" />
      </>
    ),
    star: (
      <path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6-5.4-2.9-5.4 2.9 1-6-4.4-4.3 6.1-.9z" />
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
    users: (
      <>
        <circle cx="9" cy="8" r="3" />
        <path d="M3 20a6 6 0 0 1 12 0M16 5a3 3 0 0 1 0 6M17 14a5 5 0 0 1 4 5" />
      </>
    ),
  }

  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

const levels = ["Todos", "Fundamental", "Ensino médio", "Universidade"]

const subjects = [
  {
    title: "Matemática",
    description: "Frações, álgebra e desafios de lógica.",
    level: "Fundamental",
    questions: 10,
    time: "8 min",
    icon: "math" as IconName,
    color: "violet",
    progress: 70,
  },
  {
    title: "Ciências",
    description: "Descubra os segredos da vida e da matéria.",
    level: "Fundamental",
    questions: 12,
    time: "10 min",
    icon: "flask" as IconName,
    color: "green",
    progress: 45,
  },
  {
    title: "História",
    description: "Viaje no tempo e conecte acontecimentos.",
    level: "Ensino médio",
    questions: 15,
    time: "12 min",
    icon: "book" as IconName,
    color: "orange",
    progress: 25,
  },
  {
    title: "Geografia",
    description: "Explore culturas, territórios e o planeta.",
    level: "Ensino médio",
    questions: 10,
    time: "9 min",
    icon: "globe" as IconName,
    color: "blue",
    progress: 60,
  },
  {
    title: "Física",
    description: "Entenda as forças que movem o universo.",
    level: "Universidade",
    questions: 12,
    time: "14 min",
    icon: "atom" as IconName,
    color: "pink",
    progress: 10,
  },
  {
    title: "Português",
    description: "Domine palavras, textos e interpretações.",
    level: "Universidade",
    questions: 10,
    time: "8 min",
    icon: "brain" as IconName,
    color: "yellow",
    progress: 35,
  },
]

const quizQuestions = [
  {
    question: "Qual é o resultado de 3/4 + 1/4?",
    options: ["1", "4/8", "3/8", "2"],
    answer: 0,
  },
  {
    question: "Um triângulo com três lados iguais é chamado de:",
    options: ["Escaleno", "Isósceles", "Equilátero", "Retângulo"],
    answer: 2,
  },
  {
    question: "Quanto é 8 × 7?",
    options: ["54", "56", "64", "48"],
    answer: 1,
  },
]

function App() {
  const [activeLevel, setActiveLevel] = useState("Todos")
  const [mobileOpen, setMobileOpen] = useState(false)
  const [quizOpen, setQuizOpen] = useState(false)
  const [quizIndex, setQuizIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [finished, setFinished] = useState(false)

  const filteredSubjects = useMemo(
    () =>
      activeLevel === "Todos"
        ? subjects
        : subjects.filter((subject) => subject.level === activeLevel),
    [activeLevel],
  )

  function openQuiz() {
    setQuizIndex(0)
    setSelectedAnswer(null)
    setScore(0)
    setFinished(false)
    setQuizOpen(true)
  }

  function advanceQuiz() {
    if (selectedAnswer === null) return
    if (selectedAnswer === quizQuestions[quizIndex].answer)
      setScore((value) => value + 1)
    if (quizIndex === quizQuestions.length - 1) {
      setFinished(true)
    } else {
      setQuizIndex((value) => value + 1)
      setSelectedAnswer(null)
    }
  }

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#fbfaf7] text-[#17231c]">
      <header className="relative z-40 border-b border-[#17231c]/8 bg-[#fbfaf7]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <a
            href="#"
            className="flex items-center gap-2.5"
            aria-label="Sg-6, início"
          >
            <span className="grid size-10 rotate-[-5deg] place-items-center rounded-xl bg-[#7357e8] text-white shadow-[0_6px_0_#4e38b7]">
              <span className="text-xl font-black tracking-tight">6</span>
            </span>
            <span className="font-display text-2xl font-black tracking-[-0.04em]">
              Sg-6
            </span>
          </a>

          <nav
            className="hidden items-center gap-8 text-sm font-bold md:flex"
            aria-label="Navegação principal"
          >
            <a
              href="#quizzes"
              className="transition-colors hover:text-[#7357e8]"
            >
              Quizzes
            </a>
            <a
              href="#trilhas"
              className="transition-colors hover:text-[#7357e8]"
            >
              Trilhas
            </a>
            <a
              href="#professores"
              className="transition-colors hover:text-[#7357e8]"
            >
              Para professores
            </a>
          </nav>

          <div className="hidden items-center gap-3 md:flex">
            <button className="rounded-xl px-4 py-2.5 text-sm font-extrabold transition-colors hover:bg-black/5">
              Entrar
            </button>
            <button
              onClick={openQuiz}
              className="rounded-xl bg-[#17231c] px-5 py-3 text-sm font-extrabold text-white transition-transform hover:-translate-y-0.5"
            >
              Começar grátis
            </button>
          </div>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="grid size-11 place-items-center rounded-xl border border-black/10 md:hidden"
            aria-label="Abrir menu"
          >
            <Icon name="menu" />
          </button>
        </div>
        {mobileOpen && (
          <nav className="border-t border-black/5 bg-[#fbfaf7] px-5 py-5 md:hidden">
            <div className="flex flex-col gap-4 font-bold">
              <a href="#quizzes" onClick={() => setMobileOpen(false)}>
                Quizzes
              </a>
              <a href="#trilhas" onClick={() => setMobileOpen(false)}>
                Trilhas
              </a>
              <a href="#professores" onClick={() => setMobileOpen(false)}>
                Para professores
              </a>
              <button
                onClick={openQuiz}
                className="mt-2 rounded-xl bg-[#17231c] px-5 py-3 text-white"
              >
                Começar grátis
              </button>
            </div>
          </nav>
        )}
      </header>

      <main>
        <section className="relative isolate overflow-hidden">
          <div className="pointer-events-none absolute -right-32 top-8 size-96 rounded-full bg-[#ffd951]/30 blur-3xl" />
          <div className="pointer-events-none absolute -left-40 bottom-0 size-80 rounded-full bg-[#74d6b0]/20 blur-3xl" />
          <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 py-16 lg:grid-cols-[1.05fr_.95fr] lg:px-8 lg:py-24">
            <div className="relative z-10">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#7357e8]/20 bg-[#7357e8]/8 px-4 py-2 text-sm font-extrabold text-[#5941c7]">
                <Icon name="spark" className="size-4" />
                Aprender pode ser a melhor parte do dia
              </div>
              <h1 className="font-display max-w-3xl text-5xl font-black leading-[1.02] tracking-[-0.055em] sm:text-6xl lg:text-7xl">
                Desafie sua mente.{" "}
                <span className="relative whitespace-nowrap text-[#7357e8]">
                  Vá além.
                  <svg
                    className="absolute -bottom-2 left-0 w-full text-[#ffd951]"
                    viewBox="0 0 260 15"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M3 11C59 2 165 2 257 8"
                      stroke="currentColor"
                      strokeWidth="7"
                      strokeLinecap="round"
                    />
                  </svg>
                </span>
              </h1>
              <p className="mt-7 max-w-xl text-lg font-medium leading-relaxed text-[#536158] sm:text-xl">
                Quizzes rápidos, trilhas inteligentes e desafios que transformam
                qualquer matéria em uma nova descoberta.
              </p>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <button
                  onClick={openQuiz}
                  className="group flex items-center justify-center gap-3 rounded-2xl bg-[#7357e8] px-7 py-4 font-extrabold text-white shadow-[0_7px_0_#4e38b7] transition-all hover:-translate-y-1 hover:shadow-[0_10px_0_#4e38b7] active:translate-y-1 active:shadow-[0_3px_0_#4e38b7]"
                >
                  Explorar quizzes
                  <Icon
                    name="arrow"
                    className="size-5 transition-transform group-hover:translate-x-1"
                  />
                </button>
                <a
                  href="#professores"
                  className="flex items-center justify-center gap-3 rounded-2xl border-2 border-[#17231c]/10 bg-white px-7 py-4 font-extrabold transition-colors hover:border-[#17231c]/30"
                >
                  <span className="grid size-7 place-items-center rounded-full bg-[#ffd951]">
                    <Icon name="play" className="size-4" />
                  </span>
                  Sou professor
                </a>
              </div>
              <div className="mt-9 flex flex-wrap items-center gap-x-7 gap-y-3 text-sm font-bold text-[#536158]">
                <span className="flex items-center gap-2">
                  <Icon name="check" className="size-5 text-[#28a976]" />{" "}
                  Conteúdo gratuito
                </span>
                <span className="flex items-center gap-2">
                  <Icon name="check" className="size-5 text-[#28a976]" /> Todos
                  os níveis
                </span>
                <span className="flex items-center gap-2">
                  <Icon name="check" className="size-5 text-[#28a976]" /> No seu
                  ritmo
                </span>
              </div>
            </div>

            <div className="relative mx-auto w-full max-w-xl lg:mx-0">
              <div className="absolute -left-7 top-16 z-10 hidden rotate-[-9deg] rounded-2xl bg-[#ffd951] p-4 shadow-xl sm:block">
                <Icon
                  name="star"
                  className="size-7 fill-[#17231c] text-[#17231c]"
                />
              </div>
              <div className="absolute -right-4 bottom-24 z-10 hidden rotate-[7deg] rounded-2xl bg-[#ff866e] p-4 text-white shadow-xl sm:block">
                <Icon name="brain" className="size-8" />
              </div>
              <div className="rotate-[1.5deg] rounded-[2rem] border-2 border-[#17231c]/10 bg-white p-5 shadow-[0_24px_70px_rgba(45,36,80,.14)] sm:p-7">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-[#7357e8]">
                      Desafio relâmpago
                    </p>
                    <p className="mt-1 font-display text-2xl font-black">
                      Ciências da natureza
                    </p>
                  </div>
                  <div className="grid size-12 place-items-center rounded-2xl bg-[#dff6ed] text-[#14825b]">
                    <Icon name="flask" className="size-6" />
                  </div>
                </div>
                <div className="mt-6 rounded-2xl bg-[#f3f0ff] p-5">
                  <div className="flex items-center justify-between text-xs font-extrabold text-[#6b5ab1]">
                    <span>PERGUNTA 4 DE 10</span>
                    <span>40%</span>
                  </div>
                  <div className="mt-3 h-2 overflow-hidden rounded-full bg-white">
                    <div className="h-full w-2/5 rounded-full bg-[#7357e8]" />
                  </div>
                </div>
                <p className="mt-6 font-display text-xl font-extrabold leading-snug">
                  Qual destes órgãos é responsável por bombear o sangue?
                </p>
                <div className="mt-5 grid grid-cols-2 gap-3">
                  {["Pulmão", "Coração", "Fígado", "Cérebro"].map(
                    (answer, index) => (
                      <div
                        key={answer}
                        className={`rounded-xl border-2 p-3.5 text-sm font-extrabold ${
                          index === 1
                            ? "border-[#28a976] bg-[#e8f8f1] text-[#147253]"
                            : "border-black/8 bg-white text-[#536158]"
                        }`}
                      >
                        <span
                          className={`mr-2 inline-grid size-6 place-items-center rounded-lg text-xs ${
                            index === 1
                              ? "bg-[#28a976] text-white"
                              : "bg-[#f0efec]"
                          }`}
                        >
                          {String.fromCharCode(65 + index)}
                        </span>
                        {answer}
                      </div>
                    ),
                  )}
                </div>
                <div className="mt-6 flex items-center justify-between border-t border-black/8 pt-5">
                  <span className="flex items-center gap-2 text-sm font-bold text-[#536158]">
                    <Icon name="clock" className="size-4" /> 01:24
                  </span>
                  <span className="rounded-xl bg-[#28a976] px-5 py-2.5 text-sm font-extrabold text-white">
                    Próxima
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-y border-black/5 bg-white py-8">
          <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-5 md:grid-cols-4 lg:px-8">
            {[
              ["+120", "quizzes disponíveis"],
              ["6", "áreas do conhecimento"],
              ["3", "níveis de ensino"],
              ["100%", "feito para aprender"],
            ].map(([value, label]) => (
              <div key={label} className="text-center">
                <p className="font-display text-3xl font-black text-[#7357e8]">
                  {value}
                </p>
                <p className="mt-1 text-sm font-bold text-[#657168]">{label}</p>
              </div>
            ))}
          </div>
        </section>

        <section
          id="quizzes"
          className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-24"
        >
          <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.18em] text-[#7357e8]">
                Escolha seu próximo desafio
              </p>
              <h2 className="font-display mt-3 text-4xl font-black tracking-[-0.04em] sm:text-5xl">
                O que vamos descobrir hoje?
              </h2>
              <p className="mt-4 max-w-2xl text-lg font-medium text-[#657168]">
                Conteúdos feitos para o seu momento, do ensino fundamental à
                universidade.
              </p>
            </div>
            <div className="flex max-w-full gap-2 overflow-x-auto pb-2">
              {levels.map((level) => (
                <button
                  key={level}
                  onClick={() => setActiveLevel(level)}
                  className={`shrink-0 rounded-xl px-4 py-2.5 text-sm font-extrabold transition-colors ${
                    activeLevel === level
                      ? "bg-[#17231c] text-white"
                      : "border border-black/10 bg-white text-[#657168] hover:border-black/30"
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {filteredSubjects.map((subject) => (
              <article
                key={subject.title}
                className="group flex flex-col rounded-3xl border border-black/8 bg-white p-6 transition-all hover:-translate-y-1.5 hover:shadow-[0_18px_45px_rgba(36,31,54,.1)]"
              >
                <div className="flex items-start justify-between">
                  <div className={`subject-icon subject-${subject.color}`}>
                    <Icon name={subject.icon} className="size-7" />
                  </div>
                  <span className="rounded-full bg-[#f1f0ed] px-3 py-1.5 text-xs font-extrabold text-[#657168]">
                    {subject.level}
                  </span>
                </div>
                <h3 className="font-display mt-6 text-2xl font-black">
                  {subject.title}
                </h3>
                <p className="mt-2 min-h-12 font-medium leading-relaxed text-[#657168]">
                  {subject.description}
                </p>
                <div className="mt-5 flex gap-4 text-xs font-bold text-[#768078]">
                  <span className="flex items-center gap-1.5">
                    <Icon name="book" className="size-4" /> {subject.questions}{" "}
                    questões
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Icon name="clock" className="size-4" /> {subject.time}
                  </span>
                </div>
                <div className="mt-6">
                  <div className="mb-2 flex justify-between text-xs font-extrabold">
                    <span>Seu progresso</span>
                    <span>{subject.progress}%</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-[#eeece7]">
                    <div
                      className={`progress progress-${subject.color}`}
                      style={{ width: `${subject.progress}%` }}
                    />
                  </div>
                </div>
                <button
                  onClick={openQuiz}
                  className="mt-6 flex w-full items-center justify-between rounded-xl bg-[#f5f3ef] px-4 py-3.5 text-sm font-extrabold transition-colors group-hover:bg-[#17231c] group-hover:text-white"
                >
                  Começar quiz <Icon name="chevron" className="size-4" />
                </button>
              </article>
            ))}
          </div>
        </section>

        <section id="professores" className="px-5 pb-20 lg:px-8 lg:pb-24">
          <div className="relative mx-auto max-w-7xl overflow-hidden rounded-[2rem] bg-[#17231c] px-6 py-12 text-white sm:px-12 lg:px-16 lg:py-16">
            <div className="absolute -right-20 -top-24 size-80 rounded-full border-[50px] border-[#7357e8]/40" />
            <div className="absolute bottom-0 right-1/3 size-32 translate-y-1/2 rounded-full bg-[#ffd951]/10" />
            <div className="relative grid items-center gap-10 lg:grid-cols-[1fr_auto]">
              <div className="max-w-3xl">
                <div className="mb-5 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-extrabold text-[#ffd951]">
                  <Icon name="graduation" className="size-5" /> Espaço do
                  professor
                </div>
                <h2 className="font-display text-4xl font-black tracking-[-0.04em] sm:text-5xl">
                  Ensinar também é continuar aprendendo.
                </h2>
                <p className="mt-5 max-w-2xl text-lg font-medium leading-relaxed text-white/65">
                  Reforce conteúdos do núcleo comum, encontre novas formas de
                  explicar e crie experiências mais envolventes para a sua
                  turma.
                </p>
              </div>
              <div className="relative z-10">
                <button className="flex w-full items-center justify-center gap-3 rounded-2xl bg-[#ffd951] px-7 py-4 font-extrabold text-[#17231c] shadow-[0_7px_0_#b79210] transition-transform hover:-translate-y-1 lg:w-auto">
                  Conhecer área do professor <Icon name="arrow" />
                </button>
                <p className="mt-4 text-center text-xs font-bold text-white/50">
                  Acesso gratuito para educadores
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-black/8 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-5 px-5 py-8 sm:flex-row lg:px-8">
          <div className="flex items-center gap-2 font-display text-xl font-black">
            <span className="grid size-8 place-items-center rounded-lg bg-[#7357e8] text-white">
              6
            </span>{" "}
            Sg-6
          </div>
          <p className="text-center text-sm font-bold text-[#768078]">
            Conhecimento que acompanha você em cada fase.
          </p>
          <div className="flex gap-5 text-sm font-bold text-[#657168]">
            <a href="#">Ajuda</a>
            <a href="#">Privacidade</a>
          </div>
        </div>
      </footer>

      {quizOpen && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-[#17231c]/65 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Quiz de matemática"
        >
          <div className="w-full max-w-xl rounded-[2rem] bg-white p-6 shadow-2xl sm:p-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.16em] text-[#7357e8]">
                  Quiz rápido
                </p>
                <p className="font-display mt-1 text-2xl font-black">
                  Matemática
                </p>
              </div>
              <button
                onClick={() => setQuizOpen(false)}
                className="grid size-10 place-items-center rounded-full bg-[#f1f0ed] text-xl font-bold"
                aria-label="Fechar quiz"
              >
                ×
              </button>
            </div>
            {!finished ? (
              <>
                <div className="mt-7 flex items-center gap-3">
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-[#ece9f8]">
                    <div
                      className="h-full rounded-full bg-[#7357e8] transition-all"
                      style={{
                        width: `${((quizIndex + 1) / quizQuestions.length) * 100}%`,
                      }}
                    />
                  </div>
                  <span className="text-xs font-black text-[#657168]">
                    {quizIndex + 1}/{quizQuestions.length}
                  </span>
                </div>
                <h3 className="font-display mt-7 text-2xl font-black leading-snug">
                  {quizQuestions[quizIndex].question}
                </h3>
                <div className="mt-6 grid gap-3">
                  {quizQuestions[quizIndex].options.map((option, index) => (
                    <button
                      key={option}
                      onClick={() => setSelectedAnswer(index)}
                      className={`flex items-center gap-3 rounded-xl border-2 p-4 text-left font-extrabold transition-colors ${
                        selectedAnswer === index
                          ? "border-[#7357e8] bg-[#f3f0ff] text-[#5941c7]"
                          : "border-black/8 hover:border-black/20"
                      }`}
                    >
                      <span
                        className={`grid size-7 place-items-center rounded-lg text-xs ${
                          selectedAnswer === index
                            ? "bg-[#7357e8] text-white"
                            : "bg-[#f1f0ed]"
                        }`}
                      >
                        {String.fromCharCode(65 + index)}
                      </span>
                      {option}
                    </button>
                  ))}
                </div>
                <button
                  onClick={advanceQuiz}
                  disabled={selectedAnswer === null}
                  className="mt-7 w-full rounded-xl bg-[#7357e8] px-5 py-4 font-extrabold text-white shadow-[0_5px_0_#4e38b7] transition-opacity disabled:cursor-not-allowed disabled:opacity-40"
                >
                  {quizIndex === quizQuestions.length - 1
                    ? "Ver resultado"
                    : "Próxima pergunta"}
                </button>
              </>
            ) : (
              <div className="py-8 text-center">
                <div className="mx-auto grid size-20 place-items-center rounded-3xl bg-[#ffd951] text-[#17231c]">
                  <Icon name="star" className="size-10 fill-current" />
                </div>
                <h3 className="font-display mt-6 text-3xl font-black">
                  Mandou muito bem!
                </h3>
                <p className="mt-3 text-lg font-bold text-[#657168]">
                  Você acertou {score} de {quizQuestions.length} perguntas.
                </p>
                <div className="mt-7 flex gap-3">
                  <button
                    onClick={() => setQuizOpen(false)}
                    className="flex-1 rounded-xl border-2 border-black/10 px-5 py-3.5 font-extrabold"
                  >
                    Fechar
                  </button>
                  <button
                    onClick={openQuiz}
                    className="flex-1 rounded-xl bg-[#7357e8] px-5 py-3.5 font-extrabold text-white"
                  >
                    Jogar de novo
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default App

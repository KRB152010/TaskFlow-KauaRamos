# Task Flow para Android

Projeto Android nativo que abre a demonstração Task Flow em uma WebView segura. A página e os recursos estão empacotados no app, então o painel funciona sem conexão. Os dados da demonstração ficam no armazenamento local do WebView.

## Gerar o APK

1. Abra esta pasta no Android Studio.
2. Instale o Android SDK Platform 36 quando o IDE solicitar. O projeto usa JDK 17 e Android Gradle Plugin 9.2.0; o Gradle e os componentes necessários são baixados pelo Android Studio durante a sincronização.
3. Selecione **Build > Build APK(s)**. O APK de depuração será salvo em `app/build/outputs/apk/debug/app-debug.apk`.

O ambiente em que este projeto foi preparado não tem o SDK Android configurado, portanto o APK ainda não foi compilado aqui.
